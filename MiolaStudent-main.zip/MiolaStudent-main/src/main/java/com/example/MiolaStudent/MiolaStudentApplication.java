package com.example.MiolaStudent;

import com.example.MiolaStudent.models.Etudiant;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiolaStudentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiolaStudentApplication.class, args);


	}

}
