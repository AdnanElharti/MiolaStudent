package com.example.MiolaStudent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiolaStudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
